#!/usr/bin/python

#Entrypoint 2.x
from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("Spark SQL basic example").enableHiveSupport().getOrCreate()

# On yarn:
# spark = SparkSession.builder.appName("Spark SQL basic example").enableHiveSupport().master("yarn").getOrCreate()
# specify .master("yarn")

sc = spark.sparkContext

hr = sc.textFile("file:///home/talentum/test-jupyter/spark2/hortonworks.txt")\
.map(lambda x:x.split(","))
#.map(lambda x: (x[1:],x[0]))
hr.take(2)

hr2 = hr.flatMap(lambda x: [(y , x[0]) for y in x[1:]]).reduceByKey(lambda x,y: x+" , "+y)
print(hr2.collect())
